//
//  ViewController.swift
//  TableView-Maxime-Girard-v2
//
//  Created by Maxime on 09/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var names = ["nom1","nom2","nom3"]
    
    @IBOutlet weak var textName: UITextField!
    @IBAction func btnAdd(_ sender: Any) {
        if let name = textName.text {
            names.append(name)
            textName.text = ""
            self.tableView.reloadData()
        }
    }
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        textName.delegate = self
    }
}

extension ViewController:UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print("return clicked")
        textName.resignFirstResponder()
        if let name = textName.text {
            names.append(name)
            textName.text = ""
            self.tableView.reloadData()
        }
        return true
    }
}

extension ViewController:UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "NamesList", for: indexPath)
        // setup de cell
        cell.textLabel?.text = names[indexPath.row]
        return cell
    }
}

extension ViewController:UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //let i = indexPath.row
        //return i % 2 == 0 ? 100 : 30
        return 100
    }
}
