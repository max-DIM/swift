//
//  ViewController.swift
//  Layout-Maxime-Girard
//
//  Created by Maxime on 17/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var IMG: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        label.backgroundColor = UIColor.red
    }
}

