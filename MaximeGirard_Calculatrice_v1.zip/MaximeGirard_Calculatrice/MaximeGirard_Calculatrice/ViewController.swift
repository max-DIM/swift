//
//  ViewController.swift
//  MaximeGirard_Calculatrice
//
//  Created by Digital on 26/03/2019.
//  Copyright © 2019 Digital. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelAffichage: UILabel!
    
    var operation:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func buttonChiffre(_ sender: UIButton) {
        if let valueButton = sender.titleLabel?.text{
            labelAffichage.text = valueButton
            operation += valueButton
            print(operation)
        }
    }
    
    @IBAction func buttonOperation(_ sender: UIButton) {
        if let valueButton = sender.titleLabel?.text{
            switch valueButton {
            case "=":
                labelAffichage.text = operation
                operation = ""
                print(operation)
            default:
                if operation != "" {
                    labelAffichage.text = valueButton
                    operation += valueButton
                    print(operation)
                }
            }
        }
    }
}

