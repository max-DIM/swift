//
//  ViewController.swift
//  Network-Maxime-Girard
//
//  Created by Maxime on 09/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var datas =  [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        
        print("Before request")
        AF.request("https://jsonplaceholder.typicode.com/users").responseString { response in
            
            print("Received response")
            //if let responseValue = response.value {
                //self.textView.text = responseValue
            //}
            
            //get value from response (String)
            if let userJSON = response.value {
                //convert string to Data
                let data = Data(userJSON.utf8)
                //create a decoder
                let decoder = JSONDecoder()
                do {
                    // try to decode an array of User
                    // -> User has to be conform to Codable
                    let decoded = try decoder.decode([User].self, from: data)
                    //access
                    print(decoded[0].name)
                
                    for i in 0..<decoded.count {
                        print(i)
                        self.datas.append(decoded[i].name)
                    }
                    self.tableView.reloadData()
                    
                } catch {
                    print("Failed to decode JSON")
                }
            }
            
        }
        print("After request")
    }

}

extension ViewController:UITableViewDataSource {
    // MARK: TableView Datasource
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        cell.textLabel?.text = datas[indexPath.row]
        
        return cell
    }
    
}
