//
//  User.swift
//  Network-Maxime-Girard
//
//  Created by Maxime on 09/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import Foundation

struct User:Codable {
    var id:Int
    var name:String
    var username:String
    var email:String
}
