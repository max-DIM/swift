//
//  ViewController.swift
//  Network-Maxime-Girard
//
//  Created by Maxime on 09/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Before request")
        AF.request("https://jsonplaceholder.typicode.com/users").responseString { response in
            
            print("Received response")
            //if let responseValue = response.value {
                //self.textView.text = responseValue
            //}
            
            //get value from response (String)
            if let userJSON = response.value {
                //convert string to Data
                let data = Data(userJSON.utf8)
                //create a decoder
                let decoder = JSONDecoder()
                do {
                    // try to decode an array of User
                    // -> User has to be conform to Codable
                    let decoded = try decoder.decode([User].self, from: data)
                    //access
                    print(decoded[0].name)
                } catch {
                    print("Failed to decode JSON")
                }
            }
            
        }
        print("After request")
    }

}

