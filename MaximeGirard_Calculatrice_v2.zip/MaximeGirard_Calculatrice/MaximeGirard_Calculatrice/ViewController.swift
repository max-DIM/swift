
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelAffichage: UILabel!
    
    var operation:String? = nil
    var premier:Int? = nil
    var second:Int? = nil
    var afficher:Bool = true
    var result:Int = 0
    
    override func viewDidLoad() {
        labelAffichage.layer.borderWidth = 0.3
    }
    
    @IBAction func buttonChiffre(_ sender: UIButton) {
        if let valueButton = sender.titleLabel?.text{
            let chiffre = (valueButton as NSString).integerValue
            if premier == nil {
                premier = chiffre
                afficher = true
            } else if operation != nil {
                if second == nil {
                    second = chiffre
                    afficher = true
                }
            } else {
                afficher = false
            }
            
            if afficher == true {
                labelAffichage.text = valueButton
            }
        }
    }
    
    @IBAction func buttonOperation(_ sender: UIButton) {
        if let valueButton = sender.titleLabel?.text{
            
            switch valueButton {
            case "=":
                if operation != nil,
                    premier != nil,
                    second != nil{
                    if operation == "/" &&
                        premier! == 0 || second! == 0{
                            labelAffichage.text = "Calcul impossible"
                    } else {
                        result = calc(ch1: premier!, ch2: second!, operation: operation!)
                        labelAffichage.text = "resultat: \(result)"
                    }
                    operation = nil
                    premier = nil
                    second = nil
                }
            default:
                if premier != nil {
                    operation = valueButton
                    labelAffichage.text = valueButton
                }
            }
        }
    }
    
    func calc(ch1:Int, ch2:Int, operation:String) -> Int {
        switch operation {
        case "+":
            return ch1 + ch2
        case "-":
            return ch1 - ch2
        case "/":
            return ch1 / ch2
        case "*":
            return ch1 * ch2
        default:
            return 0
        }
    }
}

