//
//  ViewController.swift
//  Network-Maxime-Girard
//
//  Created by Maxime on 09/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var datas =  [""]
    var selectedIndex = 0
    var models = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        
        print("Before request")
        AF.request("https://jsonplaceholder.typicode.com/users").responseString { response in
            
            print("Received response")
            //if let responseValue = response.value {
                //self.textView.text = responseValue
            //}
            
            //get value from response (String)
            if let userJSON = response.value {
                //convert string to Data
                let data = Data(userJSON.utf8)
                //create a decoder
                let decoder = JSONDecoder()
                do {
                    // try to decode an array of User
                    // -> User has to be conform to Codable
                    let decoded = try decoder.decode([User].self, from: data)
                    //access
                    //print(decoded[0].name)
                    self.models = decoded
                    
                    self.tableView.reloadData()
                    
                } catch {
                    print("Failed to decode JSON")
                }
            }
            
        }
        print("After request")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let dest = segue.destination as? DetailsViewController {
            dest.details = models[selectedIndex]
        }
        
    }

}

extension ViewController:UITableViewDataSource {
    // MARK: TableView Datasource
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        cell.textLabel?.text = models[indexPath.row].name
        
        return cell
    }
    
}

extension ViewController:UITableViewDelegate {
    // MARK: TableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.selectedIndex = indexPath.row
        self.performSegue(withIdentifier: "segueDetails", sender: self)
        
    }
    
}
