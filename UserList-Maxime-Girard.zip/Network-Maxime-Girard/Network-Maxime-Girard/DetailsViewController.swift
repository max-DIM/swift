//
//  DetailsViewController.swift
//  Network-Maxime-Girard
//
//  Created by Maxime on 16/04/2019.
//  Copyright © 2019 Maxime. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var details:User?
    
    @IBOutlet weak var detailsTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if let objectDetails = details {
            detailsTextView.text = "id: \(objectDetails.id)"
            detailsTextView.text += "\nname: \(objectDetails.name)"
            detailsTextView.text += "\nusername: \(objectDetails.username)"
            detailsTextView.text += "\nemail: \(objectDetails.email)"
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
